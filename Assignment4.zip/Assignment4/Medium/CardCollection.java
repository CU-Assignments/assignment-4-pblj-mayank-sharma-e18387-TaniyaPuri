import java.util.HashMap;
import java.util.ArrayList;
import java.util.Scanner;

class Card {
    private String symbol;
    private String value;

    public Card(String symbol, String value) {
        this.symbol = symbol;
        this.value = value;
    }

    public String getSymbol() {
        return symbol;
    }

    public String getValue() {
        return value;
    }

    @Override
    public String toString() {
        return value + " of " + symbol;
    }
}

public class CardCollection {
    private static HashMap<String, ArrayList<Card>> cardMap = new HashMap<>();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        initializeCards();
        
        while (true) {
            System.out.println("\nCard Collection System");
            System.out.println("1. Search Cards by Symbol");
            System.out.println("2. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    searchCardsBySymbol(scanner);
                    break;
                case 2:
                    System.out.println("Exiting the system.");
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void initializeCards() {
        ArrayList<Card> hearts = new ArrayList<>();
        hearts.add(new Card("Hearts", "Ace"));
        hearts.add(new Card("Hearts", "2"));
        hearts.add(new Card("Hearts", "3"));

        ArrayList<Card> spades = new ArrayList<>();
        spades.add(new Card("Spades", "Ace"));
        spades.add(new Card("Spades", "2"));
        spades.add(new Card("Spades", "3"));

        cardMap.put("Hearts", hearts);
        cardMap.put("Spades", spades);
    }

    private static void searchCardsBySymbol(Scanner scanner) {
        System.out.print("Enter card symbol (e.g., Hearts, Spades): ");
        String symbol = scanner.nextLine();

        if (cardMap.containsKey(symbol)) {
            ArrayList<Card> cards = cardMap.get(symbol);
            System.out.println("Cards of " + symbol + ":");
            for (Card card : cards) {
                System.out.println(card);
            }
        } else {
            System.out.println("No cards found for the given symbol.");
        }
    }
}


