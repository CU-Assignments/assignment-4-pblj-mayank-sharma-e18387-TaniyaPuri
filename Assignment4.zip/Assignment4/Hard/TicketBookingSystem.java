class TicketBookingSystem extends Thread {
    private static int availableSeats = 5;
    private String customerName;
    private boolean isVIP;

    public TicketBookingSystem(String customerName, boolean isVIP) {
        this.customerName = customerName;
        this.isVIP = isVIP;
    }

    @Override
    public void run() {
        synchronized (TicketBookingSystem.class) {
            if (availableSeats > 0) {
                if (isVIP) {
                    System.out.println("VIP Customer " + customerName + " is booking a seat...");
                } else {
                    System.out.println("Regular Customer " + customerName + " is booking a seat...");
                }

                try {
                    // Simulating the booking process
                    Thread.sleep(2000);
                } catch (InterruptedException e) {
                    System.out.println(e);
                }

                availableSeats--;
                System.out.println("Booking successful for " + customerName + ". Remaining seats: " + availableSeats);
            } else {
                System.out.println("No available seats for " + customerName);
            }
        }
    }

    public static void main(String[] args) {
        TicketBookingSystem customer1 = new TicketBookingSystem("John", false);
        TicketBookingSystem customer2 = new TicketBookingSystem("Alice", true);
        TicketBookingSystem customer3 = new TicketBookingSystem("Bob", false);
        TicketBookingSystem customer4 = new TicketBookingSystem("Eve", true);
        TicketBookingSystem customer5 = new TicketBookingSystem("Charlie", false);
        TicketBookingSystem customer6 = new TicketBookingSystem("David", true);

        // Set thread priorities for VIP customers
        customer2.setPriority(Thread.MAX_PRIORITY);
        customer4.setPriority(Thread.MAX_PRIORITY);
        customer6.setPriority(Thread.MAX_PRIORITY);

        // Start the threads
        customer1.start();
        customer2.start();
        customer3.start();
        customer4.start();
        customer5.start();
        customer6.start();
    }
}

